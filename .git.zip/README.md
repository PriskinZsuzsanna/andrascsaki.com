## Overview
Musican Homepage

### Built with

- HTML5
- SASS/SCSS
- Javascript
- Light-Dark mode
- Mobile-first


### Links

https://priskinzsuzsanna.github.io/andrascsaki.com/

### Screenshot

![andras](https://github.com/PriskinZsuzsanna/andrascsaki.com/assets/121173949/f511011d-9f13-49a0-9525-0e082457199a)
